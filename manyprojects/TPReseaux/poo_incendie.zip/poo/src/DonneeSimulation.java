import gui.GUISimulator;
import gui.Oval;
import gui.Rectangle;

import java.awt.*;
import java.util.zip.DataFormatException;


public class DonneeSimulation {
    public GUISimulator gui; //TODO associer correctement la gui, comme ils font dans invader
    private Carte carte;
    private Incendie[] liste_incendie;
    private Robot[] liste_robot;
    private String couleurForet = "#0e9b0c";
    private String couleurEau = "#3b0de0";
    private String couleurHabitat = "#efbaba";
    private String couleurRoche = "#6d4947";
    private String couleurTerrainLibre = "#ffffff";
    private String couleurChenilles = "#606060";
    private String couleurRoue = "#000000";
    private String couleurPattes = "#f1fc55";
    private String couleurDrone = "#afa8ff";

    public void setGui(GUISimulator gui) {
        this.gui = gui;
    }

    public void setListe_robot(Robot[] liste_robot) {
        this.liste_robot = liste_robot;
    }

    public void setListe_incendie(Incendie[] liste_incendie) {
        this.liste_incendie = liste_incendie;
    }


    public DonneeSimulation(Carte carte/*, Incendie[] liste_incendie, Robot[] liste_robot*/) {
        this.carte = carte;
    }

    public void draw_carte() throws DataFormatException {
        //TODO et avec les autres.
        Case case_parcourue;
        int tailleCase = (gui.getPanelWidth() / carte.getNbLignes());

        for (int lig = 0; lig < carte.getNbLignes(); lig++) {
            for (int col = 0; col < carte.getNbColonnes(); col++) {
                switch (this.carte.getCase(lig, col).getNature()) {
                    case EAU:
                        gui.addGraphicalElement(new Rectangle(col * tailleCase + tailleCase / 2, lig * tailleCase + tailleCase / 2, Color.BLACK, Color.decode(this.couleurEau), tailleCase));
                        break;
                    case FORET:
                        gui.addGraphicalElement(new Rectangle(col * tailleCase + tailleCase / 2, lig * tailleCase + tailleCase / 2, Color.BLACK, Color.decode(this.couleurForet), tailleCase));
                        break;
                    case ROCHE:
                        gui.addGraphicalElement(new Rectangle(col * tailleCase + tailleCase / 2, lig * tailleCase + tailleCase / 2, Color.BLACK, Color.decode(this.couleurRoche), tailleCase));
                        break;
                    case HABITAT:
                        gui.addGraphicalElement(new Rectangle(col * tailleCase + tailleCase / 2, lig * tailleCase + tailleCase / 2, Color.BLACK, Color.decode(this.couleurHabitat), tailleCase));
                        break;
                    case TERRAIN_LIBRE:
                        gui.addGraphicalElement(new Rectangle(col * tailleCase + tailleCase / 2, lig * tailleCase + tailleCase / 2, Color.BLACK, Color.decode(this.couleurTerrainLibre), tailleCase));
                        break;
                    default:
                        System.out.println("WTFFFFFFFFF???? Nature chelou");
                }
            }
        }
    }

    public void draw_robot() {
        int nbRobots = this.liste_robot.length;
        int tailleCase = (gui.getPanelWidth() / carte.getNbLignes());
        for (int i = 0; i < nbRobots; i++) {
            switch (liste_robot[i].getType()) {
                case "Chenilles":
                    gui.addGraphicalElement(new Oval(liste_robot[i].getPosition().getColonne() * tailleCase + tailleCase / 2, liste_robot[i].getPosition().getLigne() * tailleCase + tailleCase / 2, Color.BLACK, Color.decode(couleurChenilles), tailleCase / 2));
                    break;
                case "Roue":
                    gui.addGraphicalElement(new Oval(liste_robot[i].getPosition().getColonne() * tailleCase + tailleCase / 2, liste_robot[i].getPosition().getLigne() * tailleCase + tailleCase / 2, Color.BLACK, Color.decode(couleurRoue), tailleCase / 2));
                    break;
                case "Drone":
                    gui.addGraphicalElement(new Oval(liste_robot[i].getPosition().getColonne() * tailleCase + tailleCase / 2, liste_robot[i].getPosition().getLigne() * tailleCase + tailleCase / 2, Color.BLACK, Color.decode(couleurDrone), tailleCase / 2));
                    break;
                case "Pattes":
                    gui.addGraphicalElement(new Oval(liste_robot[i].getPosition().getColonne() * tailleCase + tailleCase / 2, liste_robot[i].getPosition().getLigne() * tailleCase + tailleCase / 2, Color.BLACK, Color.decode(couleurPattes), tailleCase / 2));
                    break;
                default:
                    System.out.println("!!Probleme : type de robot est  " + liste_robot[i].getType());
                    break;
            }
        }
    }

    public void draw_Incendie() {
        int nbIncendies = this.liste_incendie.length;
        int tailleCase = (gui.getPanelWidth() / carte.getNbLignes());
        for (int i = 0; i < nbIncendies; i++) {
            gui.addGraphicalElement(new Rectangle(liste_incendie[i].getPosition().getColonne() * tailleCase + tailleCase / 2, liste_incendie[i].getPosition().getLigne() * tailleCase + tailleCase / 2, Color.RED, Color.YELLOW, 3 * tailleCase / 5));

        }
    }
}
