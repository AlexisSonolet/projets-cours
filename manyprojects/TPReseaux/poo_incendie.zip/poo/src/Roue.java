public class Roue extends Robot {
    public Roue(Case caseCourante, double vitesse, double vitesseInit, int volumeEau, int volumeMax, float vitesseRemplissage, float vitesseDeversement) {
        super(caseCourante, vitesse, vitesseInit, 5000, 5000, 5000 / (float) 600, 100 / (float) 5);
    }

    @Override
    public String getType() {
        return "Roue";
    }

    @Override
    public void setVitesse(double vitesse) {
        if (vitesse > 0) {
            super.setVitesse(vitesse);
        }
    }

    @Override
    public double getVitesse(NatureTerrain nature){
        double vitesseMilieu = 0;
        switch(nature) {
            case TERRAIN_LIBRE:
                vitesseMilieu = super.getVitesseInit();
                break;
            case HABITAT:
                vitesseMilieu = super.getVitesseInit();
                break;
        }
        return vitesseMilieu;
    }

}
