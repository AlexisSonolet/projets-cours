public class Chenilles extends Robot {
    public Chenilles(Case caseCourante, double vitesse, double vitesseInit, int volumeEau, int volumeMax, float vitesseRemplissage, float vitesseDeversement) {
        super(caseCourante, vitesse, vitesseInit, 2000, 2000, 2000 / (float) 300, 100 / (float) 8);
    }

    @Override
    public String getType() {
        return "Chenilles";
    }

    @Override
    public void setVitesse(double vitesse) {
        assert (vitesse <= 80) : "La vitesse demandée est invalide";
        if (vitesse > 0) {
            super.setVitesse(vitesse);
        }
    }

    @Override
    public double getVitesse(NatureTerrain nature){
        double vitesseMilieu = super.getVitesseInit();
        switch(nature) {
            case EAU:
                vitesseMilieu = 0;
                break;
            case ROCHE:
                vitesseMilieu = 0;
                break;
            case FORET:
                vitesseMilieu = vitesseMilieu / 2;
        }
        return vitesseMilieu;
    }

}
