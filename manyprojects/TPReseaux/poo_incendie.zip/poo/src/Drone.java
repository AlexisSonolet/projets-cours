public class Drone extends Robot {
    public Drone(Case caseCourante, double vitesse, double vitesseInit, int volumeEau, int volumeMax, float vitesseRemplissage, float vitesseDeversement) {
        super(caseCourante, vitesse, vitesseInit, 10000, 10000, 10000 / (float) 1800, 10000 / (float) 30);
    }

    @Override
    public String getType() {
        return "Drone";
    }

    @Override
    public void setVitesse(double vitesse) {
        assert (vitesse <= 150 && vitesse > 0) : "La vitesse demandée est invalide";
            super.setVitesse(vitesse);
    }

    @Override
    public double getVitesse(NatureTerrain nature) {
        double vitesseMilieu = super.getVitesseInit();
        return vitesseMilieu;
    }

}
