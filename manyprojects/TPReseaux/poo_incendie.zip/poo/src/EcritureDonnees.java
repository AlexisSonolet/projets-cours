import java.awt.Color;

import gui.GUISimulator;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.zip.DataFormatException;


/**
 * Lecteur de cartes au format spectifié dans le sujet.
 * Les données sur les cases, robots puis incendies sont lues dans le fichier,
 * puis simplement affichées.
 * A noter: pas de vérification sémantique sur les valeurs numériques lues.
 * <p>
 * IMPORTANT:
 * <p>
 * Cette classe ne fait que LIRE les infos et les afficher.
 * A vous de modifier ou d'ajouter des méthodes, inspirées de celles présentes
 * (ou non), qui CREENT les objets au moment adéquat pour construire une
 * instance de la classe DonneesSimulation à partir d'un fichier.
 * <p>
 * Vous pouvez par exemple ajouter une méthode qui crée et retourne un objet
 * contenant toutes les données lues:
 * public static DonneesSimulation creeDonnees(String fichierDonnees);
 * Et faire des méthode creeCase(), creeRobot(), ... qui lisent les données,
 * créent les objets adéquats et les ajoutent ds l'instance de
 * DonneesSimulation.
 */
public class EcritureDonnees {


    /**
     * Lit et affiche le contenu d'un fichier de donnees (cases,
     * robots et incendies).
     * Ceci est méthode de classe; utilisation:
     * EcritureDonnees.lire(fichierDonnees)
     *
     * @param fichierDonnees nom du fichier à lire
     */
    public static void lire(String fichierDonnees)
            throws FileNotFoundException, DataFormatException {
        System.out.println("\n == Lecture du fichier" + fichierDonnees);
        EcritureDonnees lecteur = new EcritureDonnees(fichierDonnees);
        Carte carteCourante = lecteur.lireCarte();
        System.out.println(carteCourante.getNbLignes());
        lecteur.lireCase(carteCourante);
        Incendie[] listeIncendie = lecteur.lireIncendies(carteCourante);
        Robot[] listeRobot = lecteur.lireRobots(carteCourante);
        DonneeSimulation Donnees = new DonneeSimulation(carteCourante);
        scanner.close();
        Donnees.setListe_robot(listeRobot);
        Donnees.setListe_incendie(listeIncendie);
        System.out.println("\n == Lecture terminee");
        GUISimulator gui = new GUISimulator(800, 800, Color.BLACK);
        Donnees.setGui(gui);
        Donnees.draw_carte();
        Donnees.draw_Incendie();
        Donnees.draw_robot();
    }


    // Tout le reste de la classe est prive!

    private static Scanner scanner;

    /**
     * Constructeur prive; impossible d'instancier la classe depuis l'exterieur
     *
     * @param fichierDonnees nom du fichier a lire
     */
    private EcritureDonnees(String fichierDonnees)
            throws FileNotFoundException {
        scanner = new Scanner(new File(fichierDonnees));
        scanner.useLocale(Locale.US);
    }

    /**
     * Lit et affiche les donnees de la carte.
     *
     * @throws ExceptionFormatDonnees
     */
    private Carte lireCarte() throws DataFormatException {
        ignorerCommentaires();
        try {
            int nbLignes = scanner.nextInt();
            int nbColonnes = scanner.nextInt();
            int tailleCases = scanner.nextInt();    // en m
//            System.out.println("Carte " + nbLignes + "x" + nbColonnes
//                    + "; taille des cases = " + tailleCases);
            Carte Carte_courante = new Carte(nbLignes, nbColonnes);
            Carte_courante.setTailleCases(tailleCases);
            return Carte_courante;
        } catch (NoSuchElementException e) {
            throw new DataFormatException("Format invalide. "
                    + "Attendu: nbLignes nbColonnes tailleCases");
        }
        // une ExceptionFormat levee depuis lireCase est remontee telle quelle
    }


    /**
     * Lit et affiche les donnees d'une case.
     */
    private void lireCase(Carte Carte_courante) throws DataFormatException {
        int nbLignes = Carte_courante.getNbLignes();
        int nbColonnes = Carte_courante.getNbColonnes();
        for (int lig = 0; lig < nbLignes; lig++) {
            for (int col = 0; col < nbColonnes; col++) {
                ignorerCommentaires();
//                System.out.print("\nCase (" + lig + "," + col + "): ");
                String chaineNature = new String();
                //		NatureTerrain nature;

                try {
                    chaineNature = scanner.next();
                    // si NatureTerrain est un Enum, vous pouvez recuperer la valeur
                    // de l'enum a partir d'une String avec:
                    //			NatureTerrain nature = NatureTerrain.valueOf(chaineNature);

                    verifieLigneTerminee();

//                    System.out.print("nature = " + chaineNature);

                } catch (NoSuchElementException e) {
                    throw new DataFormatException("format de case invalide. "
                            + "Attendu: nature altitude [valeur_specifique]");
                }

                Case case_courante = new Case(lig, col, NatureTerrain.valueOf(chaineNature));
                Carte_courante.setCarteCases(case_courante);
            }
        }
    }


    /**
     * Lit et affiche les donnees des incendies.
     */

    private Incendie[] lireIncendies(Carte carteCourante) throws DataFormatException {
        ignorerCommentaires();
        try {
            int nbIncendies = scanner.nextInt();
            Incendie listeIncendie[] = new Incendie[nbIncendies];
            System.out.println("Nb d'incendies = " + nbIncendies);
            for (int i = 0; i < nbIncendies; i++) {
                listeIncendie[i] = lireIncendie(i);
            }
        return listeIncendie;
        } catch (NoSuchElementException e) {
            throw new DataFormatException("Format invalide. "
                    + "Attendu: nbIncendies");
        }
    }


    /**
     * Lit et affiche les donnees du i-eme incendie.
     *
     * @param i
     */
    private Incendie lireIncendie(int i) throws DataFormatException {
        ignorerCommentaires();
        System.out.print("Incendie " + i + ": ");

        try {
            int lig = scanner.nextInt();
            int col = scanner.nextInt();
            int intensite = scanner.nextInt();
            if (intensite <= 0) {
                throw new DataFormatException("incendie " + i
                        + "nb litres pour eteindre doit etre > 0");
            }
            verifieLigneTerminee();

            System.out.println("position = (" + lig + "," + col
                    + ");\t intensite = " + intensite);
            return new Incendie(lig, col, intensite);

        } catch (NoSuchElementException e) {
            throw new DataFormatException("format d'incendie invalide. "
                    + "Attendu: ligne colonne intensite");
        }
    }


    /**
     * Lit et affiche les donnees des robots.
     */


    /**
     * Lit et affiche les donnees des robots.
     */
    private Robot[] lireRobots(Carte carteCourante) throws DataFormatException {
        ignorerCommentaires();
        try {
            int nbRobots = scanner.nextInt();
            Robot listeRobot[] = new Robot[nbRobots];
            System.out.println("Nb de robots = " + nbRobots);
            for (int i = 0; i < nbRobots; i++) {
                listeRobot[i] = lireRobot(i, carteCourante);
            }
            return listeRobot;

        } catch (NoSuchElementException e) {
            throw new DataFormatException("Format invalide. "
                    + "Attendu: nbRobots");
        }
    }


    /**
     * Lit et affiche les donnees du i-eme robot.
     *
     * @param i
     */
    private Robot lireRobot(int i, Carte carteCourante) throws DataFormatException {
        ignorerCommentaires();
        System.out.print("Robot " + i + ": ");

        try {
            int lig = scanner.nextInt();
            int col = scanner.nextInt();
            System.out.print("position = (" + lig + "," + col + ");");
            String type = scanner.next();

            System.out.print("\t type = " + type);

            // lecture eventuelle d'une vitesse du robot (entier)
            System.out.print("; \t vitesse = ");
            String s = scanner.findInLine("(\\d+)");    // 1 or more digit(s) ?
            // pour lire un flottant:    ("(\\d+(\\.\\d+)?)");
            Case caseInit = carteCourante.getCase(lig, col);
            Robot robotCourant = null;
            if (s == null) {
                System.out.print("valeur par defaut");
                switch (type) {
                    case "DRONE":
                        Drone drone = new Drone(caseInit, 100, 100, 0, 0, 0, 0);
                        // System.out.print(drone.getVitesseCourante());
                        // System.out.print(drone.getVitesseInit());
                        robotCourant = drone;
                        break;
                    case "ROUES":
                        Roue roue = new Roue(caseInit, 80, 80, 0, 0, 0, 0);
                        // System.out.print(roue.getVitesseCourante());
                        // System.out.print(roue.getVitesseInit());
                        robotCourant = roue;
                        break;
                    case "CHENILLES":
                        Chenilles chenilles = new Chenilles(caseInit, 30, 30, 0, 0, 0, 0);
                        // System.out.print(pattes.getVitesseCourante());
                        // System.out.print(pattes.getVitesseInit());
                        robotCourant = chenilles;
                        break;
                    case "PATTES":
                        Pattes pattes = new Pattes(caseInit, 30, 30, 0, 0, 0, 0);
                        // System.out.print(pattes.getVitesseCourante());
                        // System.out.print(pattes.getVitesseInit());
                        robotCourant = pattes;
                        break;
                }
            } else {
                int vitesse = Integer.parseInt(s);
                System.out.print(vitesse);
                switch (type) {
                    case "DRONE":
                        Drone drone = new Drone(caseInit, vitesse, vitesse, 0, 0, 0, 0);
                        // System.out.print(drone.getVitesseCourante());
                        // System.out.print(drone.getVitesseInit());
                        robotCourant = drone;
                        break;
                    case "ROUES":
                        Roue roue = new Roue(caseInit, vitesse, vitesse, 0, 0, 0, 0);
                        // System.out.print(roue.getVitesseCourante());
                        // System.out.print(roue.getVitesseInit());
                        robotCourant = roue;
                        break;
                    case "CHENILLES":
                        Chenilles chenilles = new Chenilles(caseInit, vitesse, vitesse, 0, 0, 0, 0);
                        // System.out.print(roue.getVitesseCourante());
                        // System.out.print(roue.getVitesseInit());
                        robotCourant = chenilles;
                        break;
                    case "PATTES":
                        Pattes pattes = new Pattes(caseInit, vitesse, vitesse, 0, 0, 0, 0);
                        // System.out.print(pattes.getVitesseCourante());
                        // System.out.print(pattes.getVitesseInit());
                        robotCourant = pattes;
                        break;
                }
            }
            verifieLigneTerminee();

            System.out.println();

            return robotCourant;

        } catch (NoSuchElementException e) {
            throw new DataFormatException("format de robot invalide. "
                    + "Attendu: ligne colonne type [valeur_specifique]");
        }
    }

    /**
     * Ignore toute (fin de) ligne commencant par '#'
     */
    private void ignorerCommentaires() {
        while (scanner.hasNext("#.*")) {
            scanner.nextLine();
        }
    }

    /**
     * Verifie qu'il n'y a plus rien a lire sur cette ligne (int ou float).
     *
     * @throws ExceptionFormatDonnees
     */
    private void verifieLigneTerminee() throws DataFormatException {
        if (scanner.findInLine("(\\d+)") != null) {
            throw new DataFormatException("format invalide, donnees en trop.");
        }
    }
}
