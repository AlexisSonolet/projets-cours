import java.util.zip.DataFormatException;

public class Carte {
    private int TailleCases;
    private Case[][] carteCases;

    public Carte(int nbLignes, int nbColonnes) {
        this.carteCases = new Case[nbLignes][nbColonnes];
    }

    public void setCarteCases(Case caseCourante) {
        this.carteCases[caseCourante.getLigne()][caseCourante.getColonne()] = caseCourante;
    }

    public void setTailleCases(int tailleCases) {
        this.TailleCases = tailleCases;
    }

    public int getTailleCases() {
        return TailleCases;
    }
    public int getNbLignes() {
        return carteCases.length;
    }
    public int getNbColonnes() {
        return carteCases[0].length;
    }

    public Case getCase(int lig, int col)  throws DataFormatException{
        try {
            return carteCases[lig][col];
        } catch (Exception e) {
            throw new DataFormatException("Format invalide. "
                    + Integer.toString(lig) + " ligne demandée, et " + Integer.toString(col) + "colonne demandée");

        }
    }

    public Boolean voisinExiste(Case src, Direction dir) {
        int nl = this.getNbLignes() - 1;
        int nc = this.getNbColonnes() - 1;
        Boolean existence = true;
        switch(dir) {
            case NORD:
                if (src.getLigne()== 0) {
                    existence = false;
                }
                break;

            case SUD:
                if (src.getLigne() == nl) {
                    existence = false;
                }
                break;
            case OUEST:
                if (src.getColonne() == 0) {
                    existence = false;
                }
                break;
            case EST:
                if (src.getColonne() == nc) {
                    existence = false;
                }
                break;
        }
        return existence;
    }

    public Case getVoisin(Case src, Direction dir) throws DataFormatException{
        assert (this.voisinExiste(src, dir) == true) : "Cette case n'a pas de voisin dans la direction" + dir;
        Case voisin = new Case(0, 0, src.getNature());
        switch(dir) {
            case NORD:
                voisin = this.getCase(src.getLigne() - 1, src.getColonne());
                break;
            case SUD:
                voisin = this.getCase(src.getLigne() + 1, src.getColonne());
                break;
            case OUEST:
                voisin = this.getCase(src.getLigne(), src.getColonne() - 1);
                break;
            case EST:
                voisin = this.getCase(src.getLigne(), src.getColonne() + 1);
                break;
        }
        return voisin;
    }

}
