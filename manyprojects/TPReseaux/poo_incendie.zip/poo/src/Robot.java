public abstract class Robot {
    private Case caseCourante;
    private double vitesse;
    private double vitesseInit;
    private int volumeEau;
    private int volumeMax;
    private float vitesseRemplissage;
    private float vitesseDeversement;

    public Robot(Case caseCourante, double vitesse, double vitesseInit, int volumeEau, int volumeMax, float vitesseRemplissage, float vitesseDeversement) {
      this.caseCourante = caseCourante;
      this.vitesse = vitesse;
      this.vitesseInit = vitesseInit;
      this.volumeEau = volumeEau;
      this.volumeMax = volumeMax;
      this.vitesseRemplissage = vitesseRemplissage;
      this.vitesseDeversement = vitesseDeversement;
    }

    public abstract String  getType();

    public Case getPosition() {
        return caseCourante;
    }

    public void setPosition(Case nouvelleCase) {
      this.caseCourante = nouvelleCase;
    }

    public double getVitesseCourante() {
        return vitesse;
    }

    public double getVitesseInit() {
        return vitesseInit;
    }

    public abstract double getVitesse(NatureTerrain terrain);

    public void setVitesse(double vitesse) {
      this.vitesse = vitesse;
    }

    public int getVolumeEau() {
        return volumeEau;
    }

    public void deverserEau(int vol) {
        assert (vol <= this.volumeEau) : "le volume demandé n'est pas compatible";
        this.volumeEau = this.volumeEau - vol;
    }


    public void remplirReservoir() {
        this.volumeEau = this.volumeMax;
    }

}
