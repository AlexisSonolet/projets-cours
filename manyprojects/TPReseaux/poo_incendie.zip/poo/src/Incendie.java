import java.lang.Math;

public class Incendie {
    private int litresdeau;
    private Case caseIncendie;

    public Incendie(
            int ligne, int colonne, int litresdeau) {
        this.caseIncendie = new Case(ligne, colonne, NatureTerrain.TERRAIN_LIBRE);
        assert litresdeau >= 0;
        this.litresdeau = litresdeau;
    }

    public Case getPosition() {
        return caseIncendie;
    }

    public void eteindre(int eau) {
        this.litresdeau -= eau;
        this.litresdeau = Math.max(this.litresdeau, 0);
    }
}