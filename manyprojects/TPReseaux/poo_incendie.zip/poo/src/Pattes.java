public class Pattes extends Robot {
    public Pattes(Case caseCourante, double vitesse, double vitesseInit, int volumeEau, int volumeMax, float vitesseRemplissage, float vitesseDeversement) {
        super(caseCourante, vitesse, vitesseInit, 0, 0, 0, 10);
    }

    @Override
    public String getType() {
        return "Pattes";
    }

    @Override
    public void setVitesse(double vitesse) {
        if (vitesse > 0) {
            super.setVitesse(vitesse);
        }
    }

    @Override
    public double getVitesse(NatureTerrain nature){
        double vitesseMilieu = super.getVitesseInit();
        switch(nature) {
            case EAU:
                vitesseMilieu = 0;
                break;
            case ROCHE:
                vitesseMilieu = 10;
                break;
        }
        return vitesseMilieu;
    }
}
