public class Case {
    public Case(
            int ligne, int colonne, NatureTerrain
            nature) {

        this.ligne = ligne;
        this.colonne = colonne;
        this.nature = nature;
    }

    private int ligne;
    private int colonne;
    private NatureTerrain nature;


    public int getLigne() {
        return ligne;
    }

    public int getColonne() {
        return colonne;
    }

    @Override
    public String toString() {
        return Integer.toString(this.ligne) + " ; " + Integer.toString(this.colonne) + " nature : " + this.nature;
    }

    public NatureTerrain getNature() {
        return nature;
    }
}

